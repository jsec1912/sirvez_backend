class Footer extends React.Component {
	constructor(props) {
		super(props);
	}
	render() {
		return (
			<footer>
				<p className="footer">
					<span>Page rendered in 5 Seconds</span>
				</p>
			</footer>
		);
	}
}

export default Footer